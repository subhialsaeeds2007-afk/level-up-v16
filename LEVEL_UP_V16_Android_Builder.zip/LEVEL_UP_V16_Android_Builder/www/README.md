LEVEL UP | Subhi — V16
Fix: when a task is created with weekly/monthly daily repetition, its selected deadline is copied to every generated daily occurrence. Editing a single day's task changes only that day's copy and never propagates to other days.
All other app files and behavior are retained from V14.
